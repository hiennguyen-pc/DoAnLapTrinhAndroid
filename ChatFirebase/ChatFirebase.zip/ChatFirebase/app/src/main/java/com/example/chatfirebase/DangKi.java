package com.example.chatfirebase;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class DangKi extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dang_ki);
    }
}